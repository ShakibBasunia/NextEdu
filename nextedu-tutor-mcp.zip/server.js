#!/usr/bin/env node
/**
 * NextEdu Tutor MCP Server
 * Exposes AI tutoring tools for SSC/HSC students (Bangladesh)
 * Transport: HTTP (Streamable HTTP — MCP spec 2025-03-26)
 */

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import express from "express";

// ── Server Definition ──────────────────────────────────────────────
const server = new McpServer({
  name: "nextedu-tutor-mcp",
  version: "1.0.0",
  description: "MCP server for NextEdu — AI tutoring tools for Bangladeshi SSC/HSC students",
});

// ── Tool 1: get_syllabus_content ───────────────────────────────────
server.tool(
  "get_syllabus_content",
  "Fetch NCTB syllabus content for a given subject and chapter",
  {
    subject: z.enum(["Physics", "Chemistry", "Mathematics", "Biology", "English", "Bangla", "ICT"]).describe("Subject name"),
    chapter: z.number().int().min(1).describe("Chapter number"),
    grade: z.enum(["SSC", "HSC"]).describe("Grade level"),
  },
  async ({ subject, chapter, grade }) => {
    // In production: query your NCTB PDF database / RAG system
    const syllabus = {
      subject,
      chapter,
      grade,
      title: `${subject} — Chapter ${chapter} (${grade})`,
      topics: [
        `Core concept 1 of ${subject} Ch.${chapter}`,
        `Core concept 2 of ${subject} Ch.${chapter}`,
        `Important formulas / definitions`,
        `Board exam focus areas`,
      ],
      source: "NCTB Textbook PDF (digitized)",
    };
    return {
      content: [{ type: "text", text: JSON.stringify(syllabus, null, 2) }],
    };
  }
);

// ── Tool 2: generate_practice_question ────────────────────────────
server.tool(
  "generate_practice_question",
  "Generate SSC/HSC practice questions for a topic using Claude AI",
  {
    subject: z.string().describe("Subject name e.g. Physics"),
    topic: z.string().describe("Specific topic e.g. Newton's Laws"),
    difficulty: z.enum(["easy", "medium", "hard"]).describe("Question difficulty"),
    count: z.number().int().min(1).max(10).default(3).describe("Number of questions"),
  },
  async ({ subject, topic, difficulty, count }) => {
    const prompt = `Generate ${count} ${difficulty}-level ${subject} practice questions on "${topic}" for Bangladeshi SSC/HSC students. Format: Q1, Q2... with answers at the end. In English.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data = await res.json();
      const text = data.content?.[0]?.text || "Could not generate questions.";
      return { content: [{ type: "text", text }] };
    } catch (err) {
      return { content: [{ type: "text", text: `Error: ${err.message}` }] };
    }
  }
);

// ── Tool 3: run_rai_audit ──────────────────────────────────────────
server.tool(
  "run_rai_audit",
  "Run a Responsible AI audit for the NextEdu platform",
  {
    current_score: z.number().min(0).max(100).default(80).describe("Current RAI score out of 100"),
    practices: z.array(z.string()).describe("List of current RAI practices already in place"),
  },
  async ({ current_score, practices }) => {
    const prompt = `Perform a Responsible AI audit for NextEdu (Bangladeshi ed-tech, students aged 14-18). Current RAI score: ${current_score}/100. Existing practices: ${practices.join(", ")}. Identify top 3 gaps and fixes. Concise bullets. English.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 800,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data = await res.json();
      const text = data.content?.[0]?.text || "Audit failed.";
      return { content: [{ type: "text", text }] };
    } catch (err) {
      return { content: [{ type: "text", text: `Error: ${err.message}` }] };
    }
  }
);

// ── Tool 4: suggest_data_sources ──────────────────────────────────
server.tool(
  "suggest_data_sources",
  "Suggest additional data sources for the NextEdu platform",
  {
    existing_sources: z.array(z.string()).describe("Currently used data sources"),
    focus_area: z.string().optional().describe("Optional focus area e.g. 'science', 'Bangla NLP'"),
  },
  async ({ existing_sources, focus_area }) => {
    const prompt = `You are a data provenance assistant for NextEdu (Bangladeshi SSC/HSC ed-tech). Current data sources: ${existing_sources.join(", ")}. ${focus_area ? `Focus area: ${focus_area}.` : ""} Suggest 4-5 additional data sources with brief reasons. Concise list. English.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 600,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data = await res.json();
      const text = data.content?.[0]?.text || "No suggestions returned.";
      return { content: [{ type: "text", text }] };
    } catch (err) {
      return { content: [{ type: "text", text: `Error: ${err.message}` }] };
    }
  }
);

// ── HTTP Transport Setup ───────────────────────────────────────────
const app = express();
app.use(express.json());

app.post("/mcp", async (req, res) => {
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ NextEdu MCP Server running on http://localhost:${PORT}/mcp`);
});
