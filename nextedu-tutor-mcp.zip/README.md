# nextedu-tutor-mcp

MCP server for **NextEdu** — exposes AI tutoring tools for Bangladeshi SSC/HSC students.

## Tools (4 endpoints)

| Tool | Description |
|------|-------------|
| `get_syllabus_content` | Fetch NCTB syllabus for a subject/chapter |
| `generate_practice_question` | Generate practice questions via Claude AI |
| `run_rai_audit` | Run Responsible AI audit |
| `suggest_data_sources` | Suggest additional data sources |

## Setup

```bash
npm install
ANTHROPIC_API_KEY=your_key_here npm start
```

Server runs at: `http://localhost:3000/mcp`

## Transport
- **Protocol:** MCP (Model Context Protocol)
- **Transport:** Streamable HTTP
- **SDK:** @modelcontextprotocol/sdk
